//Ayoub Rammo, Raegeorge Decastro

//class account username SSH:  
//REDIDs : 
//CS-570, Summer 2021 
//Assignment #3
//Memory_best_fit.h

#include <cstdlib>
#include <iostream>
using namespace std;

class Nodex {
public:
    int data;
    int process_id;
    int requird_space;
    int block_allocated;
    int required_partition;
    Nodex* next;
};

class Memory_bst_fit {
private:
    Nodex *head, *tail;
    int external_frags = 0;
    int memorySize = 128;
    int num_traversed = 0;
public:

    Memory_bst_fit() {
        head = NULL;
        tail = NULL;
    }

    void initializeMem(int size) {
        
        memorySize = memorySize + size;
       
    }
    
    int get_fragments(){
    
        return external_frags;
    
    }
    
    int get_traversed(){
    
        return num_traversed;
    
    }
    
    
    void init(){
        
        
        
        Nodex *tmp;
        tmp = head;
        int count = memorySize;
        
        while (tmp != NULL && count != 0) {

            
            tmp = tmp->next;
            tmp->block_allocated = 0;
            tmp->data = 2;
            tmp->next =NULL;
            tmp->process_id = 0;
            tmp->requird_space = 0;
            tmp->required_partition = 0;
            count = count - 1;

        }

        
    
    }

    int getOccupiedPartitions(int processId) {

        Nodex *tmp;
        tmp = head;

        while (tmp != NULL) {


            if (tmp->process_id == processId) {

                return tmp->required_partition;
            }
            tmp = tmp->next;

        }

        return -1;

    }

    void allocate_best_fit(int partition_size, int proc_id, int required_space, int block_allocated, int parts) {
        Nodex *tmp = new Nodex;
        tmp->data = partition_size;
        tmp->process_id = proc_id;
        tmp->requird_space = required_space;
        tmp->block_allocated = block_allocated;
        tmp->required_partition = parts;
        tmp->next = NULL;

        if (head == NULL) {
            head = tmp;
            tail = tmp;
        } else {
            tail->next = tmp;
            tail = tail->next;
        }
    }
    
    
    

    int allocate_mem(int process_id, int num_units) {

        
        if(memorySize < num_units){
            
            return -1;
        
        }
        Nodex *tmp;
        tmp = head;
        
        int free_bock = 0;
        while (tmp != NULL && tmp->data >= num_units) {

            tmp = tmp->next;
            num_traversed++;
        }

        free_bock = num_traversed + 1;

        if (num_traversed >= 128) {

            
            return -1;
        }

        int required_partitions = 0;

        if (num_units % 2 == 0) {

            required_partitions = num_units / 2;

        } else {

            required_partitions = (num_units / 2) + 1;

        }


        external_frags = required_partitions % 2;




        for (int x = 0; x < required_partitions; x++) {

            allocate_best_fit(2, process_id, num_units, free_bock, required_partitions);
        }


        memorySize = memorySize - required_partitions;
        
        return 1;
    }

    int deallocate_mem(int process_id) {

        struct Nodex** tmp = &head;

        int partitions = getOccupiedPartitions(process_id);

        if (partitions == -1) {

            return -1;

        }

   



        while (*tmp) {

            struct Nodex* entry = *tmp;
            if (entry->process_id == process_id) {
                *tmp = entry->next;
                delete (entry);
            } else {

                tmp = &(entry->next);
            }

        }


        //initialize removed space
        initializeMem(3);

    }

    void display() {
        Nodex *tmp;
        tmp = head;

        cout << "Process ID" << " \t " << " Memory Block" << " \t " << "Space Allocated " << " Occupied Partitions " << endl;

        int prev_proc_id = tmp->process_id;

        while (tmp != NULL && tmp != 0) {

            cout << tmp->process_id << " \t\t" << tmp->block_allocated << " \t\t" << tmp->requird_space << " \t\t" << tmp->required_partition << endl;

            while (tmp->process_id == prev_proc_id && tmp != 0) {


                tmp = tmp->next;
                if (tmp == 0) {
                    break;
                }



            }


            if (tmp != NULL) {


                prev_proc_id = tmp->process_id;
            }



        }
    }
};

