//Ayoub Rammo, Raegeorge Decastro

//class account username SSH: 
//REDIDs : 
//Assignment #3
//CS-570, Summer 2021  
//memAllocation


#include <cstdlib>
#include <iostream>
#include  "Memory.h"
#include  "Memory_best_fit.h"
#include <thread>
#include <bits/stdc++.h>
using namespace std;




int memSize = 256;
int blocks = 128;
int partition_size = 2;
Memory_fst_fit memory_fst_fit;
Memory_bst_fit memory_bst_fit;

clock_t start, tend;
double time_taken_fstfit;
double time_taken_bstfit;
int fragments_fst_fit = 0;
int fragments_bst_fit = 0;

int traversed_fst_fit = 0;
int traversed_bst_fit = 0;

void request_allocation_fst_fit(int process_id, int num_units) {

    start = clock();

    int x = memory_fst_fit.allocate_mem(process_id, num_units);

    tend = clock();

    fragments_fst_fit = fragments_fst_fit + memory_fst_fit.get_fragments();
    traversed_fst_fit = traversed_fst_fit + memory_fst_fit.get_traversed();
    time_taken_fstfit = time_taken_fstfit + (double(tend - start) / double(CLOCKS_PER_SEC));


}

void request_deallocation_first_fit(int process_id) {

    memory_fst_fit.deallocate_mem(process_id);


}

void request_allocation_bst_fit(int process_id, int num_units) {

    start = clock();

    int x = memory_bst_fit.allocate_mem(process_id, num_units);

    tend = clock();


    fragments_bst_fit = fragments_bst_fit + memory_bst_fit.get_fragments();
    traversed_bst_fit = traversed_bst_fit + memory_bst_fit.get_traversed();
    time_taken_fstfit = time_taken_fstfit + (double(tend - start) / double(CLOCKS_PER_SEC));


}

void request_deallocation_bst_fit(int process_id) {

    memory_bst_fit.deallocate_mem(process_id);

}

/*
 * 
 */
int main(int argc, char** argv) {

    int success = 0;
    int failed = 0;

    cout << " Allocation and Deallocation using First Fit" << endl;
    for (int x = 0; x < 10000; x++) {

        int result = 1 + (rand() % 8);
        int proc_id = x + 1;
        request_allocation_fst_fit(proc_id, result);



    }

    cout << " Total Traversed " << traversed_fst_fit << " Total Time " << time_taken_fstfit << endl;
    cout << "External Fragments " << fragments_fst_fit << endl;
    
    memory_fst_fit.display();

    cout << " ---------------------- Allocation and Deallocation using First Fit" << endl;
    for (int x = 0; x < 10000; x++) {


        int proc_id = x + 1;
        request_deallocation_first_fit(proc_id);


    }


    cout << " Total Traversed " << traversed_fst_fit << " Total Time " << time_taken_fstfit << endl;





    cout << " Allocation and Deallocation using Best Fit" << endl;
    for (int x = 0; x < 10000; x++) {

        int result = 1 + (rand() % 8);
        int proc_id = x + 1;
        request_allocation_bst_fit(proc_id, result);

        

    }
    
    cout << " Total Traversed " << traversed_bst_fit << "Process Id " << " Total Time " << time_taken_bstfit << endl;
    cout << "External Fragments " << fragments_bst_fit << endl;
    
    
    
    memory_bst_fit.display();


    cout << " Allocation and Deallocation using Best Fit Fit" << endl;
    
    
    for (int x = 0; x < 10000; x++) {


        int proc_id = x + 1;
        request_deallocation_bst_fit(proc_id);
       


    }
    
     cout << " Total Traversed " << traversed_bst_fit << "Process Id "  << " Total Time " << time_taken_bstfit << endl;




    return 0;
}

